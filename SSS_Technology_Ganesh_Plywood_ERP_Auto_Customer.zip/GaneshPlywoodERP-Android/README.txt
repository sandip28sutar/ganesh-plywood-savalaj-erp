GANESH PLYWOOD ERP - Android project
Package: com.ganeshplywood.erp
Version: 1.0.0

Open this folder in Android Studio.
Then: Build > Generate Signed Bundle / APK > Android App Bundle.
Create/select a release keystore and build the signed AAB.

The current ERP HTML is included at:
app/src/main/assets/index.html


Customer Auto Create: Billing now accepts Customer Name, Mobile Number and Address. Saving an invoice automatically creates a new customer or updates an existing customer (matched by mobile number/name+address).
