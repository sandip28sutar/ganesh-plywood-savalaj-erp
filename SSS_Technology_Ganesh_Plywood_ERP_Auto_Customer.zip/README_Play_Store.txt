SSS Technology — Ganesh Plywood ERP

This package is prepared for Google Play submission.

Android project package:
com.sstechnology.ganeshplywooderp

App name:
Ganesh Plywood ERP

Publisher:
SSS Technology

The project includes the latest ERP HTML in app/src/main/assets/index.html.

Build AAB in Android Studio:
Build > Generate Signed Bundle / APK > Android App Bundle

Before upload:
1. Replace the support email placeholder in the privacy policy.
2. Host Privacy_Policy.html on a public HTTPS URL.
3. Create a signed release AAB.
4. Complete Play Console App content and Data Safety accurately.
5. Provide reviewer login instructions for restricted features.
